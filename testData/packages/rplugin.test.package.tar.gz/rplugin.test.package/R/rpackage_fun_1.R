rpackage_fun_1 <-
function(x) print(x)
