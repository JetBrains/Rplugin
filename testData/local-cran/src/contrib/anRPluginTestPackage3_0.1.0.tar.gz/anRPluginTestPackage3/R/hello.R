# Hello, world!
#
# This is an example function named 'hello'
# which prints 'Hello, world!'.

hello <- function() {
  print("Sample text")
}
